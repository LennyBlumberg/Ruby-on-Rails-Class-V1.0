module ApplicationHelper
	def lenny_date(d)
	d.strftime("%B %e, %Y")
	end
end
