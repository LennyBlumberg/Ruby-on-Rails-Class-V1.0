# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
BlogMysql::Application.config.secret_token = '7e716aa91b99a07838d9fa96f248afae2642226130d3b072106d91e51d92b4a76418f2224847f8138f3eb8e9b991e6588dd2ed3f9e91fd89237b96040e80efe9'
